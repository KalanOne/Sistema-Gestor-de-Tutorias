$(document).ready(function () {
  $("#User_last_name").removeAttr("hidden");
  $("#PadreMadreTutor_apellidos").removeAttr("hidden");
});
